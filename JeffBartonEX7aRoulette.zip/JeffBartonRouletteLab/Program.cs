﻿using System;

namespace JeffBartonRouletteLab
{
    class Program
    {
        static void Main(string[] args)
        {
            new App().Run();
        }
    }
}
