﻿using System;
using System.Collections.Generic;
using System.Text;
/*
 
Bets: Inside / Outside 18 red v black numbers
Inside:
Straightup - individual number payout odds 35:1
             hitting odds 37:1

Split - 2 adjoining numbers vert or horiz 17:1

Street - 3 number horiz 11:1

Coner - 4 numbers at vert and horiz intersection 8:1

Outside:
2:1, or 1:1 based on how much of the board is emcopasssed by the bets
odd v even

red v black

1st v 2nd v 3rd 12
1-12 v 13-24 v 25-36

column bets. each column 2:1 odds consisting of 12 numbers
Column 1 – This covers the ball landing on the numbers 1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34
Column 2 – This covers the ball landing on numbers 2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35
Column 3 – This covers the ball landing on numbers 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36
Each column pays 2:1, or double your bet.
*/
namespace JeffBartonRouletteLab
{
    class notes
    {
    }
}
